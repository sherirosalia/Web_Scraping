
Web_Scraping

Mars web scraping and visualization project using python, beautiful soup and html in order to get the latest news about Mars.
